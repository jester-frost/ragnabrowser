function loginsucess() {
	setTimeout("window.location='select.php'",5000);
}
function loginfail() {
	setTimeout("window.location='login.php'",5000);
}
function logout() {
	setTimeout("window.location='index.php'",5000);
}